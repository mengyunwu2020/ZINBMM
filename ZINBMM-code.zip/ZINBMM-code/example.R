source('ZINBMM.R')
load('example.rda')

mat = example$mat
Bmat = example$batch_mat
##Run ZINBMM model
results = ZINBMM(mat, Bmat, lib = rep(1, dim(mat)[1]), K = 3, 
        phi_init = NULL, phi_global = TRUE,
        tune_set = NULL, ntune = 8, ncores = 8, 
        max_iter_init = 200, max_iter = 300)

##Clustering result
results$Clust
##Gene selection result
results$Gene
