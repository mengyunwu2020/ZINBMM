library(Brobdingnag)
library(parallel)
LogLikFunc <- function(mat, lib, Bmat, k, 
                       gamma, beta, phi, pi, pc, z){
  n = dim(mat)[1]
  p = dim(mat)[2]
  
  mult_pdf<-matrix(NA,nrow=n,ncol=k)
  set_vec <- exp(Bmat %*% gamma )
  
  for(i in 1:n){
    for(l in 1:k){
      mult_pdf[i,l]<-as.numeric(mult_density(x=mat[i,],mu=set_vec[i] * exp(beta[,l]),
                                              phi,pi=pi[,l]))
    }
  } 
  
  pc_mat = matrix(rep(pc,n), nrow = n, byrow = TRUE)
  
  loglik = sum(z * (log(pc_mat) + mult_pdf))
  
  return(loglik)
}

LogLikFunc_onek <- function(mat, lib, Bmat, k, 
                            gamma, beta, phi, pi){
  n = dim(mat)[1]
  p = dim(mat)[2]
  
  mult_pdf<-c()
  set_vec <- exp(Bmat %*% gamma )
  
  for(i in 1:n){
    mult_pdf[i]<-as.numeric(mult_density(x=mat[i,],mu=set_vec[i] * exp(beta),
                                              phi,pi=pi))
  } 
  
  loglik_onek = sum(mult_pdf)
  
  return(loglik_onek)
}
Init<- function(mat, lib, Bmat, k = 1, max_iter_init = 200, phi_init = NULL, phi_global = TRUE){
  
  n = dim(mat)[1]
  p = dim(mat)[2] 
  
  phi_old = phi_init ; if(!length(phi_old)) phi_old = rep(1, p)
  
  pi_old= apply(mat, MARGIN = 2, function(x){sum(x == 0)/n})
  gamma_old = rep(0, dim(Bmat)[2])
  
  beta_old = log(apply(mat, MARGIN = 2, mean)+1e-03)
  
  
  iter_init = 0
  repeat{
    
    set_mat <- matrix(rep(exp(Bmat %*% gamma_old + log(lib)),p), nrow = n, byrow = FALSE)
    pi_mat <- matrix(rep(pi_old,n), nrow = n, byrow = TRUE)
    phi_mat <- matrix(rep(phi_old,n), nrow = n, byrow = TRUE)
    beta_mat <- matrix(rep(exp(beta_old),n),nrow = n, byrow = TRUE)
    mu_mat <- set_mat * beta_mat 
    
    ##unobserved m 
    m <- pi_mat/(pi_mat + (1-pi_mat)*(phi_mat/(mu_mat + phi_mat))^phi_mat) * (mat == 0)
    
    
    ##update pi
    pi_new <- apply(m, MARGIN = 2, sum)
    pi_new = pi_new / n
    
    ##update gamma with IRLS
    if(length(gamma_old)==1){gamma_new = gamma_old}else{
    gamma_new = gamma_update(mat,lib,Bmat, gamma_old,
                             beta_old, phi_old,
                             k = 1, z = NULL, m, max_iter = 300)}
    
    ##update beta with IRLS
    beta_new = beta_vec_update(mat, lib, Bmat,
                               gamma_new, beta_old, phi_old, 
                               beta_global = NULL, lambda = NULL,
                               z = rep(1,n), m, 
                               penalize = FALSE,
                               max_iter = 300)
    ##update phi
    if(length(phi_init)){ phi_new = phi_old }else{
    if(phi_global){
    psi_new = psi_global_update(mat,lib,Bmat,log(phi_old[1]),beta_new,gamma_new,m)
    phi_new = rep(exp(psi_new),p)}else{
      psi_new = psi_update(mat,lib,Bmat,log(phi_old),beta_new,gamma_new,m)
      phi_new = exp(psi_new)
    }
    }
    
    iter_init = iter_init + 1
    
    if(iter_init > max_iter_init){break}
    
    if(max(max(abs(beta_new - beta_old)),
           max(abs(pi_new - pi_old)),
           max(abs(gamma_new- gamma_old)),
           max(abs(phi_new- phi_old))) < 10^(-3)){break}

    # print(c(max(abs(beta_new - beta_old)), 
    #         max(abs(pi_new - pi_old)),
    #         max(abs(gamma_new- gamma_old)),
    #         max(abs(phi_new - phi_old))))
    beta_old = beta_new
    pi_old = pi_new
    gamma_old = gamma_new
    phi_old = phi_new
    
  } 
  
  return(list('beta_global' = beta_new, 
              'pi' = pi_new,
              'phi' = phi_old,
              'gamma' = gamma_new ))
}
gamma_update  = function(mat, lib, Bmat, gamma_old, beta, phi,
                         k, z, m, max_iter = 500){
  n = dim(mat)[1]
  p = dim(mat)[2]
  
  phi_mat = matrix(rep(phi,n), nrow = n, byrow = TRUE)
  
  iter_gamma = 0
  repeat{
    set_mat = matrix(rep(exp(Bmat %*% gamma_old ) * lib, p), nrow = n, byrow = FALSE)
    
    A_mat = B_mat = matrix(0, nrow = n, ncol = p)
    
    if(k == 1){
      beta_mat = matrix(rep(exp(beta),n),nrow = n, byrow = TRUE)
      mu_mat = set_mat * beta_mat 
      
      A_mat = ( 1 - m ) * phi_mat * (mat - mu_mat) /(mu_mat*(mu_mat + phi_mat)) * mu_mat
      B_mat = A_mat + (1 - m ) * (-2 * phi_mat * mat * mu_mat + phi_mat * mu_mat^2 - phi_mat^2 * mat )/
        (mu_mat^2 * (mu_mat + phi_mat)^2 ) * mu_mat^2
    }else{
      for (l in 1:k){
        
        beta_mat <- matrix( rep(exp(beta[,l]),n), nrow = n, byrow = TRUE)
        mu_mat = set_mat * beta_mat 
        
        dmumat = z[,l] * ( 1 - m[[l]] ) * phi_mat * (mat - mu_mat) /(mu_mat*(mu_mat + phi_mat)) * mu_mat
        dmu2mat = dmumat +  z[,l] * ( 1 - m[[l]] )* (-2 * phi_mat * mat * mu_mat + phi_mat * mu_mat^2 - phi_mat^2 * mat )/
          (mu_mat^2 * (mu_mat + phi_mat)^2 ) * mu_mat^2
        A_mat = A_mat + dmumat
        B_mat = B_mat + dmu2mat
      }
    }
    dmu_sumj = apply(A_mat, MARGIN = 1, sum) ## n dot 1
    dmu2_sumj = apply(B_mat, MARGIN = 1, sum)
    
    dgamma = apply(dmu_sumj * Bmat, 2, sum) ## n dot b 
    dgamma2 = apply(dmu2_sumj * Bmat, 2, sum)
    
    gamma_new = gamma_old - dgamma / dgamma2
    iter_gamma = iter_gamma +1
    if(iter_gamma > max_iter){break}
    if(max(abs(gamma_new - gamma_old)) < 10^(-7)){break}
    gamma_old = gamma_new
  }
  return(gamma_new)
}

beta_vec_update = function(mat, lib, Bmat, 
                           gamma, beta_old, phi, 
                           beta_global, lambda,
                           z_vec, m_mat, 
                           penalize,
                           max_iter = 200){
  n = dim(mat)[1]
  p = dim(mat)[2]
  
  set_mat = matrix(rep(exp(Bmat %*% gamma ) * lib, p), nrow = n, byrow = FALSE)
  phi_mat = matrix(rep(phi,n), nrow = n, byrow = TRUE)
  
  iter_beta = 0
  repeat{
    beta_mat = matrix(rep(beta_old, n), nrow = n, byrow = TRUE)
    
    mu_mat = set_mat * exp(beta_mat)
    
    A_mat = phi_mat *(mat - mu_mat)/(mu_mat * (mu_mat + phi_mat)) * mu_mat
    B_mat = A_mat + (-2 * phi_mat * mat * mu_mat + phi_mat * mu_mat^2 - phi_mat^2 * mat )/
      (mu_mat^2 * (mu_mat + phi_mat)^2 ) * mu_mat^2
    
    omega_mat = B_mat 
    tau_mat =  beta_mat - A_mat/B_mat
    a_mat <- matrix(0, nrow = n, ncol = p)
    
    loc = which(B_mat == 0,arr.ind=T)
    
    if( length(loc)){
      tau_mat[loc] = 0
      a_mat[loc] = A_mat[loc]
      index = unique(loc[,2])
    }
    
    beta_tilde = apply((z_vec * (1 - m_mat) * (omega_mat * tau_mat - a_mat)  ),  MARGIN = 2, sum)
    # sum_vec= apply((z_vec * (1 - m_mat) * omega_mat),  MARGIN = 2, sum)
    beta_tilde = beta_tilde / apply((z_vec * (1 - m_mat) * omega_mat),  MARGIN = 2, sum)
    #  beta_tilde[which(sum_vec == 0)] =log(apply(z_vec * mat, 2, mean ))[which(sum_vec == 0)]
    
    ### extraordinary beta handle
    beta_control = log(apply(z_vec * mat, 2, function(x){sum(x)/sum(z_vec)})+0.01)
    beta_tilde[which(is.nan(beta_tilde))] = beta_control[which(is.nan(beta_tilde))]
    beta_tilde[which(beta_tilde<=log(0.01)|beta_tilde>=log(1000))] = beta_control[which(beta_tilde<=log(0.01)|beta_tilde>=log(1000))]
    
    
    if(penalize){
      betanew = apply((z_vec * (1 - m_mat) * omega_mat * tau_mat ),  MARGIN = 2, sum) +
        lambda * sign(beta_tilde - beta_global)
      betanew = betanew / apply((z_vec * (1 - m_mat) * omega_mat),  MARGIN = 2, sum)
      
      for(j in 1:p){
        betanew[j] = ifelse( (sign(beta_tilde-beta_global) * (betanew - beta_global))[j] >0 , 
                             betanew[j], beta_global[j])
      }
    }else{
      betanew = beta_tilde
    }
    betanew[which(is.nan(betanew))] = beta_control[which(is.nan(betanew))]
    betanew[which(betanew<=log(0.01)|betanew>=log(1000))] = beta_control[which(betanew<=log(0.01)|betanew>=log(1000))]
    betanew[which(is.na(betanew))] = beta_control[which(is.na(betanew))]
    
    iter_beta = iter_beta +1
    if(iter_beta > max_iter){break}
  #  print(iter_beta)
  #  print(quantile(abs(betanew-beta_old),0.85))
    if(quantile(abs(betanew-beta_old),0.95) < 10^(-10)){break}
  #  if(max(abs(betanew-beta_old)) < 10^(-7)){break}
    beta_old = betanew
  }
  return(betanew)
}

beta_mat_update = function(mat, lib, Bmat, k,
                           gamma, beta_old, phi, 
                           beta_global, lambda,
                           z, m, 
                           penalize = TRUE,
                           max_iter = 200){
  n = dim(mat)[1]
  p = dim(mat)[2]
  beta_new_mat = matrix(NA, nrow = p, ncol = k)
  for ( l in 1:k){
    beta_new_mat[,l] = beta_vec_update(mat, lib, Bmat, 
                                       gamma, beta_old[,l], phi, 
                                       beta_global, lambda,
                                       z[,l], m[[l]], 
                                       penalize,
                                       max_iter)
  }
  return(beta_new_mat)
  
}

psi_update  = function(mat, lib, Bmat, psi_old, beta, gamma, m, max_iter = 500){
  n = dim(mat)[1]
  p = dim(mat)[2]
  
  set_mat = matrix(rep(exp(Bmat %*% gamma ) * lib, p), nrow = n, byrow = FALSE)
  beta_mat = matrix(rep(exp(beta),n),nrow = n, byrow = TRUE)
  mu_mat = set_mat * beta_mat 
  iter_psi = 0
  repeat{
    A_mat = B_mat = matrix(0, nrow = n, ncol = p)
    psi_mat = matrix(rep(psi_old,n), nrow = n, byrow = TRUE)
    phi_mat = exp(psi_mat)
    
    A_mat =  (1 - m)* (digamma(mat + phi_mat) - digamma(phi_mat) - 
                         (mat + phi_mat)/(mu_mat + phi_mat) + log(phi_mat) -
                         log(mu_mat + phi_mat) + 1) * phi_mat  
    B_mat = A_mat + (1 - m)* (trigamma(mat + phi_mat) - trigamma(phi_mat) - 
                                (mu_mat - mat)/(mu_mat+ phi_mat)^2 + 
                                1.0/phi_mat - 1.0/(mu_mat+phi_mat))* phi_mat^2
    
    dpsi = apply( A_mat, 2, sum)  
    dpsi2 = apply(B_mat, 2, sum)
    
    psi_new = psi_old - dpsi/dpsi2
    
    iter_psi = iter_psi + 1
    if(iter_psi > max_iter){break}
    # print(iter_psi)
    #  print(max(abs(psi_new - psi_old)))
    if(max(abs(psi_new - psi_old)) < 10^(-7)){break}
    psi_old = psi_new
  }
  return(psi_new)
}

psi_global_update  = function(mat, lib, Bmat, psi_global_old, beta, gamma, m, max_iter = 500){
  n = dim(mat)[1]
  p = dim(mat)[2]
  
  set_mat = matrix(rep(exp(Bmat %*% gamma ) * lib, p), nrow = n, byrow = FALSE)
  beta_mat = matrix(rep(exp(beta),n),nrow = n, byrow = TRUE)
  mu_mat = set_mat * beta_mat 
  iter_psi = 0
  repeat{
    A_mat = B_mat = matrix(0, nrow = n, ncol = p)
    psi_mat = matrix(psi_global_old, nrow = n, ncol = p, byrow = TRUE)
    phi_mat = exp(psi_mat)
    
    A_mat =  (1 - m)* (digamma(mat + phi_mat) - digamma(phi_mat) - 
                         (mat + phi_mat)/(mu_mat + phi_mat) + log(phi_mat) -
                         log(mu_mat + phi_mat) + 1) * phi_mat  
    B_mat = A_mat + (1 - m)* (trigamma(mat + phi_mat) - trigamma(phi_mat) - 
                                (mu_mat - mat)/(mu_mat+ phi_mat)^2 + 
                                1.0/phi_mat - 1.0/(mu_mat+phi_mat))* phi_mat^2
    
    dpsi = sum(A_mat)
    dpsi2 = sum(B_mat)
    
    psi_global_new = psi_global_old - dpsi/dpsi2
    
    iter_psi = iter_psi + 1
    if(iter_psi > max_iter){break}
    # print(iter_psi)
    #  print(max(abs(psi_new - psi_old)))
    if(max(abs(psi_global_new - psi_global_old)) < 10^(-7)){break}
    psi_global_old = psi_global_new
  }
  return(psi_global_new)
}


mult_density<-function(x,mu,phi=1,pi){
  density_log = log(pi* (x == 0)+ (1-pi)*dnbinom(x,mu=mu,size=phi,log=FALSE))
  density_log[which(density_log==-Inf)] = log(1e-20)
  sum<-sum(density_log)
  return(sum)
}

ZINBMM_one_tune <- function(mat, Bmat, lib = rep(1, dim(mat)[1]), args0, K,lambda, max_iter = 300){
  
  n = dim(mat)[1]
  p = dim(mat)[2]
if(K > 1){
  iter_em = 0
  beta_global = args0$beta_global
  phi = args0$phi
  ## shift mean for initial values
  beta_init = NULL
  for(k in 1:K){
    beta_init = cbind(beta_init, beta_global+0.01*(k-1))
  }
  pi_old = matrix(rep(args0$pi,K),nrow = p, byrow =FALSE)
  beta_old = beta_init
  gamma_old = args0$gamma
  pc_old = rep(1/K,K)
  repeat{
    
    mult_pdf<-matrix(NA,nrow=n,ncol=K)
    set_vec <- exp(Bmat %*% gamma_old )
    
    for(i in 1:n){
      for(l in 1:K){
        mult_pdf[i,l]<-as.numeric(mult_density(x=mat[i,],mu=set_vec[i] * exp(beta_old[,l]),
                                                    phi, pi=pi_old[,l]))
      }
    }
    
    
    ###Updating z matrix
    z<-matrix(NA,nrow=n,ncol=K)
    for(i in 1:n){
      d<-brob(mult_pdf[i,])*pc_old
      #prior probability for each cluster (pi)
      z[i,]<-as.numeric(d/sum(d))
    }
    
    m <- list()
    set_mat <- matrix(rep(exp(Bmat %*% gamma_old + log(lib)),p), nrow = n, byrow = FALSE)
    phi_mat <- matrix(rep(phi,n), nrow = n, byrow = TRUE)
    
    for ( l in 1:K){
      pi_mat <- matrix(rep(pi_old[,l],n), nrow = n, byrow = TRUE)
      beta_mat <- matrix(rep(exp(beta_old[,l]),n),nrow = n, byrow = TRUE)
      mu_mat <- set_mat * beta_mat
      m[[l]] <- pi_mat/(pi_mat + (1-pi_mat)*(phi_mat/(mu_mat + phi_mat))^phi_mat) * (mat == 0)
    }
    ## update pc
    pc_new = apply(z, 2, sum)/ n
    
    ## update pi
    pi_new <- matrix(NA, nrow = p, ncol = K)
    for ( l in 1:K){
      s = z[,l] * m[[l]]
      s = apply( s, MARGIN = 2, sum)/ sum(z[,l])
      pi_new[,l] = s
    }
    
    pi_new[which(pi_new>=0.99)] = 0.99
    ## update gamma IRLS
    if(length(gamma_old)==1){gamma_new = gamma_old}else{
      gamma_new = gamma_update(mat,lib,Bmat, gamma_old,
                               beta_old, phi,
                               k = K, z = z, m, max_iter = 500)
}

    
    ## update beta IRLS
    beta_new = beta_mat_update(mat, lib, Bmat, k = K,
                               gamma_new, beta_old, phi,
                               beta_global, lambda,
                               z, m, penalize = TRUE,
                               max_iter = 100)
    
    iter_em = iter_em + 1
    if(iter_em > max_iter){break}
    # if(max(max(abs(beta_new - beta_old)),
    #        max(abs(pi_new - pi_old)),
    #        max(abs(gamma_new- gamma_old)),
    #        max(abs(pc_new - pc_old))) < 10^(-3)){break}
    if(max(quantile(abs(beta_new - beta_old),0.95),
           quantile(abs(pi_new - pi_old),0.95),
           max(abs(gamma_new- gamma_old)),
           max(abs(pc_new - pc_old))) < 10^(-3)){break}
    print(iter_em)
    # print('absolute')
    print(c(as.numeric(quantile(abs(beta_new - beta_old),0.95)),
            as.numeric(quantile(abs(pi_new - pi_old),0.95)),
            max(abs(gamma_new- gamma_old)),
            max(abs(pc_new - pc_old))))
    beta_old = beta_new
    gamma_old = gamma_new
    pi_old = pi_new
    pc_old = pc_new
  }
  result_list = list('beta' = beta_new, 'pi' = pi_new,
                     'gamma' = gamma_new, 'zmatrix' = z,
                     'pclust' = pc_new)
  log_lik_vector = LogLikFunc(mat, lib, Bmat, k=K,
                              gamma_new, beta_new, phi, pi_new, pc_new, z)
  num_beta  <- apply( beta_new, 1, function(x)length(unique(x)))
  s = sum(num_beta)
}else{
  result_list = list('beta' = args0$beta_global,'pi' = args0$pi,
                     'gamma' = args0$gamma)
  log_lik_vector = LogLikFunc_onek(mat,lib,Bmat,k=1,gamma = args0$gamma,beta = args0$beta_global,
                                   phi = args0$phi,pi = args0$pi)
  s = length(args0$beta_global)
}
  
  BIC = -2 * log_lik_vector  + log(n) * (K - 1 + s + dim(Bmat)[2] + p*K)  
  BIC_modified = -2 * log_lik_vector  +  log(n)* log(log(p))* (K - 1 + s + dim(Bmat)[2] + p*K) 
  return(list('result' = result_list,
              'bic' = BIC,
              'bic_modified' = BIC_modified))
}


ZINBMM <- function(mat, Bmat, lib = rep(1, dim(mat)[1]), K = 3, 
                   phi_init = NULL, phi_global = TRUE,
                   tune_set = NULL, ntune = 8, ncores = 8, 
                   max_iter_init = 200, max_iter = 300){
  
  n = dim(mat)[1]
  p = dim(mat)[2]
  k = K
  
  if(!length(tune_set)) tune_set = seq(0,20,length.out = ntune)
  
  args0 = Init(mat,lib,Bmat,k = 1, max_iter_init, phi_init, phi_global)
  
  mc.cores= ncores
  models<-mclapply(1:length(tune_set),function(i){
    res<-ZINBMM_one_tune(mat,Bmat,lib,args0,K=K,lambda = tune_set[i], max_iter)
    return(res)
  },mc.cores=mc.cores)
  
  model0 = models[[which.min(sapply(models,function(x)x$bic))]]
  clust = apply(model0$result$zmatrix, 1, which.max)
  beta = which(apply(model0$result$beta,1,function(x)length(unique(x)))!=1)
  gamma = model0$result$gamma
  pclust = model0$result$pclust
  
  return(list('Clust' = apply(model0$result$zmatrix, 1, which.max),
              'Gene' = which(apply(model0$result$beta,1,function(x)length(unique(x)))!=1),
              'gamma' = model0$result$gamma,
               'pi'= model0$result$pi,
               'pclust' = model0$result$pclust,
               'BIC' = sapply(models,function(x)x$bic))) 
}
